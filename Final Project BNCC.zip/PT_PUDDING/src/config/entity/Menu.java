package config.entity;

public class Menu {

    private String kodeMenu;
    private String namaMenu;
    private int hargaMenu;
    private int stokMenu;

    public String getKodeMenu() {
        return kodeMenu;
    }

    public void setKodeMenu(String kodeMenu) {
        this.kodeMenu = kodeMenu;
    }

    public String getNamaMenu() {
        return namaMenu;
    }

    public void setNamaMenu(String namaMenu) {
        this.namaMenu = namaMenu;
    }

    public int getHargaMenu() {
        return hargaMenu;
    }

    public void setHargaMenu(int hargaMenu) {
        this.hargaMenu = hargaMenu;
    }

    public int getStokMenu() {
        return stokMenu;
    }

    public void setStokMenu(int stokMenu) {
        this.stokMenu = stokMenu;
    }

}
