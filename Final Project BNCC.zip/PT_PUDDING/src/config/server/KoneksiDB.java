package config.server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import javax.swing.JOptionPane;

public class KoneksiDB {

    private java.sql.Connection conn;

    public Connection createConnection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Properties props = new Properties();
            props.put("user", "root");
            props.put("password", "");
            String DB_URL = "jdbc:mysql://localhost:3306/pt_pudding";
            conn = DriverManager.getConnection(DB_URL, props);
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal Menghubungkan Server Database.\nPesan: "
                    + e.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
        return conn;
    }

}
