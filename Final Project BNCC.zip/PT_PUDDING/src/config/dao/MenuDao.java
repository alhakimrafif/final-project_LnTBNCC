package config.dao;

import config.Model;
import config.entity.Menu;
import config.server.KoneksiDB;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MenuDao {
    
    private DefaultTableModel listMenu;
    
    public void tambahMenu(Menu menu) {
        Connection conn = new KoneksiDB().createConnection();
        try {
            conn.setAutoCommit(false);
            
            String sql = "INSERT INTO menu(kode_menu, nama_menu, harga_menu, stok_menu) VALUES (?,?,?,?)";
            PreparedStatement post = conn.prepareStatement(sql);
            post.setString(1, menu.getKodeMenu());
            post.setString(2, menu.getNamaMenu());
            post.setInt(3, menu.getHargaMenu());
            post.setInt(4, menu.getStokMenu());
            post.executeUpdate();
            
            conn.commit();
            JOptionPane.showMessageDialog(null, "Data Menu Berhasil Diposting", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            try {
                conn.rollback();
                conn.close();
                JOptionPane.showMessageDialog(null, "Gagal Memposting Data Menu.\nPesan: " + e.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
            } catch (HeadlessException | SQLException ex) {
                JOptionPane.showMessageDialog(null, "Server Error:\n" + ex.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public void editMenuByKodeMenu(Menu menu) {
        Connection conn = new KoneksiDB().createConnection();
        try {
            conn.setAutoCommit(false);
            
            String sql = "UPDATE menu SET nama_menu = (?), harga_menu =(?), stok_menu = (?) WHERE kode_menu = (?)";
            PreparedStatement post = conn.prepareStatement(sql);
            post.setString(1, menu.getNamaMenu());
            post.setInt(2, menu.getHargaMenu());
            post.setInt(3, menu.getStokMenu());
            post.setString(4, menu.getKodeMenu());
            post.executeUpdate();
            
            conn.commit();
            JOptionPane.showMessageDialog(null, "Data Menu Berhasil Diedit", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            try {
                conn.rollback();
                conn.close();
                JOptionPane.showMessageDialog(null, "Gagal Mengedit Data Menu.\nPesan: " + e.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
            } catch (HeadlessException | SQLException ex) {
                JOptionPane.showMessageDialog(null, "Server Error:\n" + ex.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public void hapusMenuByKodeMenu(Menu menu) {
        Connection conn = new KoneksiDB().createConnection();
        try {
            conn.setAutoCommit(false);
            
            String sql = "DELETE FROM menu WHERE kode_menu = (?)";
            PreparedStatement post = conn.prepareStatement(sql);
            post.setString(1, menu.getKodeMenu());
            post.executeUpdate();
            
            conn.commit();
            JOptionPane.showMessageDialog(null, "Data Menu Berhasil Dihapus", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            try {
                conn.rollback();
                conn.close();
                JOptionPane.showMessageDialog(null, "Gagal Menghapus Data Menu.\nPesan: " + e.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
            } catch (HeadlessException | SQLException ex) {
                JOptionPane.showMessageDialog(null, "Server Error:\n" + ex.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public void pilihMenuByKodeMenu(Menu menu) {
        if (menu.getKodeMenu().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Silakan pilih kode menu", "Informasi", JOptionPane.INFORMATION_MESSAGE);
        } else {
            try {
                String sql = "SELECT kode_menu, nama_menu, harga_menu, stok_menu FROM menu WHERE kode_menu = (?)";
                PreparedStatement pst = new KoneksiDB().createConnection().prepareStatement(sql);
                pst.setString(1, menu.getKodeMenu().trim());
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    menu.setKodeMenu(rs.getString(1));
                    menu.setNamaMenu(rs.getString(2));
                    menu.setHargaMenu(rs.getInt(3));
                    menu.setStokMenu(rs.getInt(4));
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Server Error:\n" + ex.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public DefaultTableModel getListMenu() {
        try {
            listMenu = new DefaultTableModel();
            Model.refreshRowDefaultTableModel(listMenu);
            String sql = "SELECT kode_menu, nama_menu, harga_menu, stok_menu FROM menu";
            String[] kolom = {"No.", "Kode", "Nama", "Harga", "Stok"};
            listMenu.setColumnIdentifiers(kolom);
            ResultSet rs = new KoneksiDB().createConnection().createStatement().executeQuery(sql);
            while (rs.next()) {
                listMenu.addRow(new Object[]{
                    listMenu.getRowCount() + 1 + ".",
                    rs.getString(1),
                    rs.getString(2),
                    new DecimalFormat().format(rs.getInt(3)),
                    rs.getInt(4)
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Server Error:\n" + ex.getMessage(), "Terjadi Kesalahan", JOptionPane.ERROR_MESSAGE);
        }
        return listMenu;
    }
    
}
