package main;

import config.dao.MenuDao;
import config.entity.Menu;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class Main extends JFrame {

    private final MenuDao menuDao = new MenuDao();

    private JLabel txt_Kode_Menu;
    private JLabel txt_Nama;
    private JLabel txt_Harga;
    private JLabel txt_Stok;

    private JTextField tx_Kode_Menu;
    private JTextField tx_Nama;
    private JTextField tx_Harga;
    private JTextField tx_Stok;

    private JButton bt_Tambah;
    private JButton bt_Edit;
    private JButton bt_Hapus;
    private JButton bt_Tutup;

    private JTable tb_Data;
    private JPanel contentPane;

    Random random = new Random();
    String randomKode;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Main frame = new Main();
                    frame.setVisible(true);
                    frame.setTitle("PT Pudding");
                    frame.setLocationRelativeTo(null);
                    frame.setResizable(false);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Main() {
        settheme("Windows");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocation(100, 100);
        setSize(400, 500);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        //label
        txt_Kode_Menu = new JLabel();
        txt_Kode_Menu.setLocation(20, 50);
        txt_Kode_Menu.setSize(70, 20);
        txt_Kode_Menu.setText("Kode Menu");
        contentPane.add(txt_Kode_Menu);

        txt_Nama = new JLabel();
        txt_Nama.setLocation(20, 80);
        txt_Nama.setSize(70, 20);
        txt_Nama.setText("Nama");
        contentPane.add(txt_Nama);

        txt_Harga = new JLabel();
        txt_Harga.setLocation(20, 110);
        txt_Harga.setSize(70, 20);
        txt_Harga.setText("Harga");
        contentPane.add(txt_Harga);

        txt_Stok = new JLabel();
        txt_Stok.setLocation(20, 140);
        txt_Stok.setSize(70, 20);
        txt_Stok.setText("Stok");
        contentPane.add(txt_Stok);

        //textfield
        tx_Kode_Menu = new JTextField();
        tx_Kode_Menu.setColumns(10);
        tx_Kode_Menu.setLocation(100, 50);
        tx_Kode_Menu.setSize(120, 20);
        contentPane.add(tx_Kode_Menu);

        tx_Nama = new JTextField();
        tx_Nama.setColumns(10);
        tx_Nama.setLocation(100, 80);
        tx_Nama.setSize(120, 20);
        contentPane.add(tx_Nama);

        tx_Harga = new JTextField();
        tx_Harga.setColumns(10);
        tx_Harga.setLocation(100, 110);
        tx_Harga.setSize(120, 20);
        contentPane.add(tx_Harga);

        tx_Stok = new JTextField();
        tx_Stok.setColumns(10);
        tx_Stok.setLocation(100, 140);
        tx_Stok.setSize(120, 20);
        contentPane.add(tx_Stok);

        tb_Data = new JTable();
        
        JTextField tf = new JTextField();
        tf.setEditable(false);
        DefaultCellEditor editor = new DefaultCellEditor(tf);
        tb_Data.setDefaultEditor(Object.class, editor);
        JScrollPane scrollPane = new JScrollPane(tb_Data);
        scrollPane.setLocation(20, 210);
        scrollPane.setSize(345, 230);
        contentPane.add(scrollPane);

        bt_Tambah = new JButton();
        bt_Tambah.setText("Tambah");
        bt_Tambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (bt_Tambah.getText().equalsIgnoreCase("Tambah")) {
                    bt_Tambah.setText("Simpan");
                    bt_Edit.setEnabled(false);
                    bt_Hapus.setEnabled(false);
                    bt_Tutup.setText("Batal");
                    aktif();
                } else {
                    tx_Kode_Menu.setText(getRandom());
                    if (tx_Nama.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(getContentPane(), "Masukan Nama Menu");
                    } else if (tx_Harga.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(getContentPane(), "Masukan Harga Menu");
                    } else if (tx_Stok.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(getContentPane(), "Masukan Stok Menu");
                    } else {
                        Menu menu = new Menu();
                        menu.setKodeMenu(tx_Kode_Menu.getText());
                        menu.setNamaMenu(txt_Nama.getText());
                        menu.setHargaMenu(Integer.parseInt(tx_Harga.getText()));
                        menu.setStokMenu(Integer.parseInt(tx_Stok.getText()));
                        menuDao.tambahMenu(menu);
                        initLoadForm();
                    }
                }
            }
        });
        bt_Tambah.setLocation(20, 170);
        bt_Tambah.setSize(80, 30);
        contentPane.add(bt_Tambah);

        bt_Edit = new JButton();
        bt_Edit.setText("Edit");
        bt_Edit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tb_Data.getSelectedRow() == -1) {
                    JOptionPane.showMessageDialog(getContentPane(), "Silakan Pilih Kode Menu");
                } else {
                    if (bt_Edit.getText().equalsIgnoreCase("Edit")) {
                        tx_Kode_Menu.setEditable(false);
                        bt_Edit.setText("Simpan");
                        bt_Tambah.setEnabled(false);
                        bt_Hapus.setEnabled(false);
                        bt_Tutup.setText("Batal");
                        tx_Kode_Menu.setText(tb_Data.getValueAt(tb_Data.getSelectedRow(), 1).toString());
                        tx_Nama.setText(tb_Data.getValueAt(tb_Data.getSelectedRow(), 2).toString());
                        tx_Harga.setText(tb_Data.getValueAt(tb_Data.getSelectedRow(), 3).toString());
                        tx_Stok.setText(tb_Data.getValueAt(tb_Data.getSelectedRow(), 4).toString());
                        aktif();
                    } else {
                        tx_Kode_Menu.setText(getRandom());
                        if (tx_Nama.getText().isEmpty()) {
                            JOptionPane.showMessageDialog(getContentPane(), "Masukan Nama Menu");
                        } else if (txt_Harga.getText().isEmpty()) {
                            JOptionPane.showMessageDialog(getContentPane(), "Masukan Harga Menu");
                        } else if (tx_Stok.getText().isEmpty()) {
                            JOptionPane.showMessageDialog(getContentPane(), "Masukan Stok Menu");
                        } else {
                            Menu menu = new Menu();
                            menu.setKodeMenu(tb_Data.getValueAt(tb_Data.getSelectedRow(), 1).toString());
                            menu.setNamaMenu(tx_Nama.getText());
                            menu.setHargaMenu(Integer.parseInt(tx_Harga.getText()));
                            menu.setStokMenu(Integer.parseInt(tx_Stok.getText()));
                            menuDao.editMenuByKodeMenu(menu);
                            initLoadForm();
                        }
                    }
                }
            }
        });
        bt_Edit.setLocation(100, 170);
        bt_Edit.setSize(80, 30);
        contentPane.add(bt_Edit);

        bt_Hapus = new JButton();
        bt_Hapus.setText("Hapus");
        bt_Hapus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (tb_Data.getSelectedRow() == -1) {
                    JOptionPane.showMessageDialog(getContentPane(), "Silakan Pilih Kode Menu");
                } else {
                    int ask = JOptionPane.showConfirmDialog(getContentPane(), "Apakah menu ini akan dihapus?", "Konfirmasi", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if (ask == JOptionPane.YES_OPTION) {
                        Menu menu = new Menu();
                        menu.setKodeMenu(tb_Data.getValueAt(tb_Data.getSelectedRow(), 1).toString());
                        menuDao.hapusMenuByKodeMenu(menu);
                        initLoadForm();
                    } else {
                        initLoadForm();
                    }
                }
            }
        });
        bt_Hapus.setLocation(180, 170);
        bt_Hapus.setSize(80, 30);
        contentPane.add(bt_Hapus);

        bt_Tutup = new JButton();
        bt_Tutup.setText("Tutup");
        bt_Tutup.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (bt_Tutup.getText().equalsIgnoreCase("Batal")) {
                    initLoadForm();
                } else {
                    System.exit(0);
                }
            }
        });
        bt_Tutup.setLocation(260, 170);
        bt_Tutup.setSize(80, 30);
        contentPane.add(bt_Tutup);
        initLoadForm();
    }

    private void initLoadForm() {
        tb_Data.setModel(menuDao.getListMenu());
        tx_Kode_Menu.setEditable(true);
        tx_Nama.setText(null);
        tx_Harga.setText(null);
        tx_Stok.setText(null);
        bt_Edit.setText("Edit");
        bt_Hapus.setText("Hapus");
        bt_Tambah.setText("Tambah");
        bt_Tutup.setText("Tutup");
        bt_Edit.setEnabled(true);
        bt_Hapus.setEnabled(true);
        bt_Tambah.setEnabled(true);
        bt_Tutup.setEnabled(true);
        tableRenderer();
        tx_Kode_Menu.setText(getRandom());
    }

    private void aktif() {
        tx_Kode_Menu.setEnabled(true);
        tx_Nama.setEnabled(true);
        tx_Harga.setEnabled(true);
        tx_Stok.setEnabled(true);
    }

    private void tableRenderer() {
        tb_Data.getTableHeader().setReorderingAllowed(false);
        tb_Data.getTableHeader().setFont(new java.awt.Font("Roboto", 0, 13));
        tb_Data.setFont(new java.awt.Font("Roboto", 0, 13));
        tb_Data.getColumnModel().getColumn(0).setPreferredWidth(50);
        tb_Data.getColumnModel().getColumn(1).setPreferredWidth(100);
        tb_Data.getColumnModel().getColumn(2).setPreferredWidth(250);
        tb_Data.getColumnModel().getColumn(3).setPreferredWidth(100);
        tb_Data.getColumnModel().getColumn(4).setPreferredWidth(100);
    }

    public void settheme(String theme) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if (theme.equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }

    public String getRandom() {
        int x = random.nextInt(999);
        String y = x+"";
        if (y.length() == 1) {
            y = x + "00";
        } else if (y.length() == 2) {
            y = x + "0";
        } else {
            y = x + "";
        }
        randomKode = ("PD-" + y);
        return randomKode;
    }
}
